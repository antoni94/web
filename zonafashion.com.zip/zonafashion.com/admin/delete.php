<?php
include "koneksi.php";
error_reporting(E_ALL ^ E_NOTICE);
$id = $_GET['id'];
$nama = $_GET['nama'];


$delete = "DELETE FROM `zonafashion`.`produk` WHERE `produk`.`id` ='$id'";
$hasil = mysql_query($delete);

if ($hasil){
//header ('location:view.php');
echo " <center> <b> <font color = 'red' size = '10'> <p> Data Berhasil dihapus </p> </center> </b> </font> <br/>
 <meta http-equiv='refresh' content='2; url= home.php?aksi=produk'/>  ";
} else { echo "Data gagal dihapus";
}

?>