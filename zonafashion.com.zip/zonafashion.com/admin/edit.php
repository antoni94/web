<?php	
    if($aksi=='edit_produk'){
    ?>
    <style>
    input[type=text],select,textarea{width:400px;margin:10px 0 10px 0;padding:10px;resize:none}
    textarea{height:200px;}
    input[type=submit]{margin:10px 0 10px 0;outline:0;background:#2ecc71;color:#fff;border:0;padding:10px;cursor:pointer}
    </style>
    <div class="isimain">
    <span class="span">Edit produk</span> 
    <form action="handler.php?aksi=tambah_produk" method="post" enctype="multipart/form-data">
    <input type="text" name="nama_produk" placeholder="Nama Produk" required><br>
    <input type="text" name="harga" placeholder="Harga" required><br>
    <span>Pilih gambar </span><input type="file" name="gambar"  required><br>
        <p style="font-size: 13px; margin-top: 10px; color: #ccc">*Kelompok Produk</p>
          <select name="kelompok">
           <?php 
            $data=mysql_query("SELECT * from kelompok order by id desc");
           ?>
           <?php 
             while (list($n,$k)=mysql_fetch_array($data)) {
               ?>
                 <option value="<?php echo $k; ?>"><?php echo $k; ?></option>
               <?php
             }
            ?>
             
           </select><br>
    <p style="font-size: 13px; margin-top: 10px; color: #ccc">*Katalog</p>
          <select name="katalog">
           <?php 
            $data=mysql_query("SELECT * from Katalog order by id_katalog desc");
           ?>
           <?php 
             while (list($n,$k)=mysql_fetch_array($data)) {
               ?>
                 <option value="<?php echo $k; ?>"><?php echo $k; ?></option>
               <?php
             }
            ?>
             
           </select><br>
    <input type="text" name="qty" placeholder="Qty" required><br>
    <input type="text" name="kategori" placeholder="Kategori"><br>
    <textarea placeholder="Detail barang" name="ket" required></textarea><br>
    <input type="submit" value="Tambahkan">
    </form>