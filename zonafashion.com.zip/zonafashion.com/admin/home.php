<?php 
error_reporting(0);
session_start();
if(!$_SESSION['id']){
	?>
    <Script>
    alert("anda harus login terlebih dalulu");
	window.location.href="index.php";
    </script>
    
    <?php

}else{ ?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Admin Zona Fashion | Dashboard Admin</title>
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  <!-- Tell the browser to be responsive to screen width -->
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../dist/css/AdminLTE.min.css">
  <!-- Material Design -->
  <link rel="stylesheet" href="../dist/css/bootstrap-material-design.min.css">
  <link rel="stylesheet" href="../dist/css/ripples.min.css">
  <link rel="stylesheet" href="../dist/css/MaterialAdminLTE.min.css">
  <!-- MaterialAdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="../dist/css/skins/all-md-skins.min.css">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- Material Design -->
  <link rel="stylesheet" href="dist/css/bootstrap-material-design.min.css">
  <link rel="stylesheet" href="dist/css/ripples.min.css">
  <link rel="stylesheet" href="dist/css/MaterialAdminLTE.min.css">
  <!-- MaterialAdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="dist/css/skins/all-md-skins.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="plugins/datatables/dataTables.bootstrap.css">
  <!-- Morris chart -->
  <link rel="stylesheet" href="plugins/morris/morris.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="plugins/jvectormap/jquery-jvectormap-1.2.2.css">
  <!-- Date Picker -->
  <link rel="stylesheet" href="plugins/datepicker/datepicker3.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="plugins/daterangepicker/daterangepicker.css">
  <!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="loader"></div>
<div class="wrapper">

  <header class="main-header">
    <!-- Logo -->
    <a href="home.php" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini">Z<b>F</b></span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg">Zona Fashion<b></b></span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- Messages: style can be found in dropdown.less-->
          <li class="dropdown messages-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-envelope-o"></i>
              <span class="label label-success">4</span>
            </a>
            <ul class="dropdown-menu">
              <li class="header">You have 4 messages</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                  <li><!-- start message -->
                    <a href="#">
                      <div class="pull-left">
                        <img src="dist/img/user-160x160.jpg" class="img-circle" alt="User Image">
                      </div>
                      <h4>
                        Support Team
                        <small><i class="fa fa-clock-o"></i> 5 mins</small>
                      </h4>
                      <p>Why not buy a new awesome theme?</p>
                    </a>
                  </li>
                  <!-- end message -->
                  <li>
                    <a href="#">
                      <div class="pull-left">
                        <img src="dist/img/user3-128x128.jpg" class="img-circle" alt="User Image">
                      </div>
                      <h4>
                        AdminLTE Design Team
                        <small><i class="fa fa-clock-o"></i> 2 hours</small>
                      </h4>
                      <p>Why not buy a new awesome theme?</p>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div class="pull-left">
                        <img src="dist/img/user4-128x128.jpg" class="img-circle" alt="User Image">
                      </div>
                      <h4>
                        Developers
                        <small><i class="fa fa-clock-o"></i> Today</small>
                      </h4>
                      <p>Why not buy a new awesome theme?</p>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div class="pull-left">
                        <img src="dist/img/user3-128x128.jpg" class="img-circle" alt="User Image">
                      </div>
                      <h4>
                        Sales Department
                        <small><i class="fa fa-clock-o"></i> Yesterday</small>
                      </h4>
                      <p>Why not buy a new awesome theme?</p>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <div class="pull-left">
                        <img src="dist/img/user4-128x128.jpg" class="img-circle" alt="User Image">
                      </div>
                      <h4>
                        Reviewers
                        <small><i class="fa fa-clock-o"></i> 2 days</small>
                      </h4>
                      <p>Why not buy a new awesome theme?</p>
                    </a>
                  </li>
                </ul>
              </li>
              <li class="footer"><a href="#">See All Messages</a></li>
            </ul>
          </li>
          <!-- Notifications: style can be found in dropdown.less -->
          <li class="dropdown notifications-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-bell-o"></i>
              <span class="label label-warning">10</span>
            </a>
            <ul class="dropdown-menu">
              <li class="header">You have 10 notifications</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                  <li>
                    <a href="#">
                      <i class="fa fa-users text-aqua"></i> 5 new members joined today
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <i class="fa fa-warning text-yellow"></i> Very long description here that may not fit into the
                      page and may cause design problems
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <i class="fa fa-users text-red"></i> 5 new members joined
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <i class="fa fa-shopping-cart text-green"></i> 25 sales made
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <i class="fa fa-user text-red"></i> You changed your username
                    </a>
                  </li>
                </ul>
              </li>
              <li class="footer"><a href="#">View all</a></li>
            </ul>
          </li>
          <!-- Tasks: style can be found in dropdown.less -->
          <li class="dropdown tasks-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-flag-o"></i>
              <span class="label label-danger">9</span>
            </a>
            <ul class="dropdown-menu">
              <li class="header">You have 9 tasks</li>
              <li>
                <!-- inner menu: contains the actual data -->
                <ul class="menu">
                  <li><!-- Task item -->
                    <a href="#">
                      <h3>
                        Design some buttons
                        <small class="pull-right">20%</small>
                      </h3>
                      <div class="progress xs">
                        <div class="progress-bar progress-bar-aqua" style="width: 20%" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">
                          <span class="sr-only">20% Complete</span>
                        </div>
                      </div>
                    </a>
                  </li>
                  <!-- end task item -->
                  <li><!-- Task item -->
                    <a href="#">
                      <h3>
                        Create a nice theme
                        <small class="pull-right">40%</small>
                      </h3>
                      <div class="progress xs">
                        <div class="progress-bar progress-bar-green" style="width: 40%" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">
                          <span class="sr-only">40% Complete</span>
                        </div>
                      </div>
                    </a>
                  </li>
                  <!-- end task item -->
                  <li><!-- Task item -->
                    <a href="#">
                      <h3>
                        Some task I need to do
                        <small class="pull-right">60%</small>
                      </h3>
                      <div class="progress xs">
                        <div class="progress-bar progress-bar-red" style="width: 60%" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">
                          <span class="sr-only">60% Complete</span>
                        </div>
                      </div>
                    </a>
                  </li>
                  <!-- end task item -->
                  <li><!-- Task item -->
                    <a href="#">
                      <h3>
                        Make beautiful transitions
                        <small class="pull-right">80%</small>
                      </h3>
                      <div class="progress xs">
                        <div class="progress-bar progress-bar-yellow" style="width: 80%" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100">
                          <span class="sr-only">80% Complete</span>
                        </div>
                      </div>
                    </a>
                  </li>
                  <!-- end task item -->
                </ul>
              </li>
              <li class="footer">
                <a href="#">View all tasks</a>
              </li>
            </ul>
          </li>
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="dist/img/user-160x160.jpg" class="user-image" alt="User Image">
              <span class="hidden-xs">
              <?php
$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "zonafashion";
$koneksi = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
$sqlCommand = "SELECT * FROM admin"; 
$query = mysqli_query($koneksi, $sqlCommand) or die (mysqli_error()); 
$row = mysqli_fetch_row($query);
echo "Selamat datang $row[3]";
mysqli_free_result($query); 
mysqli_close($koneksi);
?>
              </span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="dist/img/user-160x160.jpg" class="img-circle" alt="User Image">

                <p>
                <?php
$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "zonafashion";
$koneksi = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
$sqlCommand = "SELECT * FROM admin"; 
$query = mysqli_query($koneksi, $sqlCommand) or die (mysqli_error()); 
$row = mysqli_fetch_row($query);
echo "Selamat datang $row[3]";
mysqli_free_result($query); 
mysqli_close($koneksi);
?> <br> <small>Admin Zona Fashion</small>
                  <small></small>
                </p>
              </li>
              <!-- Menu Body -->
              <li class="user-body">
                <div class="row">
                  <div class="col-xs-4 text-center">
                    <a href="#">Followers</a>
                  </div>
                  <div class="col-xs-4 text-center">
                    <a href="#">Sales</a>
                  </div>
                  <div class="col-xs-4 text-center">
                    <a href="#">Friends</a>
                  </div>
                </div>
                <!-- /.row -->
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="#" class="btn btn-default btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="handler.php?aksi=logout" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
          <!-- Control Sidebar Toggle Button -->
          <li>
            <a href="#" data-toggle="control-sidebar"><i class="fa fa-gears"></i></a>
          </li>
        </ul>
      </div>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="dist/img/user-160x160.jpg" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?php
$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "zonafashion";
$koneksi = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
$sqlCommand = "SELECT * FROM admin"; 
$query = mysqli_query($koneksi, $sqlCommand) or die (mysqli_error()); 
$row = mysqli_fetch_row($query);
echo "Selamat datang $row[3]";
mysqli_free_result($query); 
mysqli_close($koneksi);
?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>
      <!-- search form -->
      <form action="#" method="get" class="sidebar-form">
        <div class="input-group">
          <input type="text" name="q" class="form-control" placeholder="Search...">
              <span class="input-group-btn">
                <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
        </div>
      </form>
      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">
        <li class="header">MAIN NAVIGATION</li>
        <li class="active treeview">
          <a href="home.php">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          </li>
        <li><a href="home.php?aksi=tambah_kelompok"><i class="fa fa-plus"></i> <span>Tambah Kelompok Barang</span></a></li>
        <li><a href="home.php?aksi=tambah_katalog"><i class="fa fa-plus"></i> <span>Tambah Katalok</span></a></li>
        <li><a href="home.php?aksi=produk"><i class="fa fa-tags"></i> <span>Barang</span></a></li>
        <li><a href="home.php?aksi=tampil_user"><i class="fa fa-user"></i> <span>Pengguna</span></a></li>
        <li><a href="home.php?aksi=pesan"><i class="fa fa-envelope-o"></i> <span>Pesanan</span></a></li>
        
    </section>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Dashboard
        <small>Control panel</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
         <!-- Small boxes (Stat box) -->
         <div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3><?php
$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "zonafashion";
$koneksi = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
$sqlCommand = "SELECT COUNT(*) FROM selesai";
$query = mysqli_query($koneksi, $sqlCommand) or die (mysqli_error());
$row = mysqli_fetch_row($query);
echo "$row[0]";
mysqli_free_result($query);
mysqli_close($koneksi);
?></h3>

              <p>New Orders</p>
            </div>
            <div class="icon">
              <i class="ion ion-bag"></i>
            </div>
            </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3><?php
$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "zonafashion";
$koneksi = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
$sqlCommand = "SELECT COUNT(*) FROM kelompok";
$query = mysqli_query($koneksi, $sqlCommand) or die (mysqli_error());
$row = mysqli_fetch_row($query);
echo "$row[0]";
mysqli_free_result($query);
mysqli_close($koneksi);
?>
<sup style="font-size: 20px"></sup></h3>

              <p>Kelompok Barang</p>
            </div>
            <div class="icon">
              <i class="ion ion-stats-bars"></i>
            </div>
            </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3><?php
$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "zonafashion";
$koneksi = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
$sqlCommand = "SELECT COUNT(*) FROM katalog";
$query = mysqli_query($koneksi, $sqlCommand) or die (mysqli_error());
$row = mysqli_fetch_row($query);
echo "$row[0]";
mysqli_free_result($query);
mysqli_close($koneksi);
?></h3>

              <p>Katalog</p>
            </div>
            <div class="icon">
              <i class="ion ion-person-add"></i>
            </div>
            
          </div>
        </div>
        <!-- ./col -->
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3><?php
$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "zonafashion";
$koneksi = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
$sqlCommand = "SELECT COUNT(*) FROM pembeli";
$query = mysqli_query($koneksi, $sqlCommand) or die (mysqli_error());
$row = mysqli_fetch_row($query);
echo "$row[0]";
mysqli_free_result($query);
mysqli_close($koneksi);
?></h3>

              <p>User</p>
            </div>
            <div class="icon">
              <i class="ion ion-pie-graph"></i>
            </div>
            </div>
        </div>
        <!-- ./col -->
      </div>

    <div class="main">
    <?php 
    error_reporting(0);
    include "root.php";
    $db=new admin();
    $aksi=$_GET['aksi'];
    if($aksi=='produk'){
      
    ?>	
    <style>
    td,th{border:1px solid #ccc;padding:10px;}
    table{border-collapse:collapse; width: 50%;}
    </style>
    <section class="content">
    <div class="isimain">
    <span class="span">Produk</span> 
    <a style='padding:10px;color:#fff;background:#3498db;display:inline-block' href='home.php?aksi=tambah_produk'>Tambah</a>
    <div class="box">
            <div class="box-header">
              <h3 class="box-title">Data Barang</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                <th>Gambar</th>
                <th>Nama Produk</th>
                <th>Harga</th>
                <th>QTY</th>
                <th>Kelompok</th>
                <th>Kategori</th>
                <th>Keterangan</th>
                <th>Aksi</th>
                
              </tr>
                </thead>
                <tbody>
                <?php
    $barang=$db->lihat_produk();
    foreach($barang as $r){
      echo"
                <tr>
                  <td><img style='width:100px;height:100px' src='".$r[gambar]."'></td>
                  <td>".$r[nama_produk]."</td>
                  <td>".$r[harga]."</td>
                  <td>".$r[qty]."</td>
                  <td>".$r[kelompok]."</td>
                  <td>".$r[kategori]."</td>
                  <td>".substr($r[ket],0,20)."...</td>
                  

                  <td><form action = 'delete.php' method = 'GET'>
                  <input type = 'hidden' name = 'nama' value = '".$r[nama_produk]."'>
                  <input type = 'hidden' name = 'id' value = '".$r[id]."'>
                  
                  <input type = 'submit' name = 'tombol2' value = 'Delete' class = 'delete'
                  onclick='return tanya(". $r[id].")'>
                  
                  </form></td>
                </tr>
                ";
              }
              ?>
                

              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        </div>
    </section>
    <?php	
    }
    if($aksi=='tambah_produk'){
    ?>
    <style>
    input[type=text],select,textarea{width:400px;margin:10px 0 10px 0;padding:10px;resize:none}
    textarea{height:200px;}
    input[type=submit]{margin:10px 0 10px 0;outline:0;background:#2ecc71;color:#fff;border:0;padding:10px;cursor:pointer}
    </style>
    <div class="isimain">
    <span class="span">Tambah produk</span> 
    <form action="handler.php?aksi=tambah_produk" method="post" enctype="multipart/form-data">
    <input type="text" name="nama_produk" placeholder="Nama Produk" required><br>
    <input type="text" name="harga" placeholder="Harga" required><br>
    <span>Pilih gambar </span><input type="file" name="gambar"  required><br>
        <p style="font-size: 13px; margin-top: 10px; color: #ccc">*Kelompok Produk</p>
          <select name="kelompok">
           <?php 
            $data=mysql_query("SELECT * from kelompok order by id desc");
           ?>
           <?php 
             while (list($n,$k)=mysql_fetch_array($data)) {
               ?>
                 <option value="<?php echo $k; ?>"><?php echo $k; ?></option>
               <?php
             }
            ?>
             
           </select><br>
    <p style="font-size: 13px; margin-top: 10px; color: #ccc">*Katalog</p>
          <select name="katalog">
           <?php 
            $data=mysql_query("SELECT * from Katalog order by id_katalog desc");
           ?>
           <?php 
             while (list($n,$k)=mysql_fetch_array($data)) {
               ?>
                 <option value="<?php echo $k; ?>"><?php echo $k; ?></option>
               <?php
             }
            ?>
             
           </select><br>
    <input type="text" name="qty" placeholder="Qty" required><br>
    <input type="text" name="kategori" placeholder="Kategori"><br>
    <textarea placeholder="Detail barang" name="ket" required></textarea><br>
    <input type="submit" value="Tambahkan">
    </form>
    </div>
    <?php }
    if ($aksi=="tambah_kelompok") {
      ?>
      <style>
    input[type=text],select,textarea{width:400px;margin:10px 0 10px 0;padding:10px;resize:none}
    textarea{height:200px;}
    input[type=submit]{margin:10px 0 10px 0;outline:0;background:#2ecc71;color:#fff;border:0;padding:10px;cursor:pointer}
    </style>
      <div class="isimain">
        <span class="span">Tambah Kelompok Barang</span> 
        <form action="handler.php?aksi=tambah_kelompok" method="post" enctype="multipart/form-data">
        <input type="text" name="nama" placeholder="Nama Kelompok Barang"><br>
        <input type="submit" value ="Simpan">
        </form>
        </div>
      <?php
    }
    if ($aksi=="tambah_katalog") {
      ?>
        <style>
    input[type=text],select,textarea{width:400px;margin:10px 0 10px 0;padding:10px;resize:none}
    textarea{height:200px;}
    input[type=submit]{margin:10px 0 10px 0;outline:0;background:#2ecc71;color:#fff;border:0;padding:10px;cursor:pointer}
    </style>
      <div class="isimain">
        <span class="span">Tambah Katalog</span> 
        <form action="handler.php?aksi=tambah_katalog" method="post" enctype="multipart/form-data">
        <input type="text" name="nama_katalog" placeholder="Nama Katalog"><br>
        <input type="submit" value ="Simpan">
        </form>
        </div>
      <?php
    }
    if ($aksi=="tampil_user") {
      ?>
      <style>
    td,th{border:1px solid #ccc;padding:10px;}
    table{border-collapse:collapse; width: 50%;}
    </style>
    <div class="isimain">
    <span class="span">Semua Pengguna  Aktif</span> 
    <Table>
    <tr><th>Nama Pengguna</th><th>Email</th><th>Alamat</th><th>provinsi</th><th>Kabupaten/Kota</th><th>Kecamatan</th><th>Kode Pos</th><th>Telpon</th></tr>
    <?php
    $pembeli=$db->member();
    foreach($pembeli as $r){
      echo "<tr><td> ".$r[nama_lengkap]."</td><td>".$r[email]."</td><td>".$r[alamat]."</td><td>".$r[provinsi]."</td><td>".$r[kabupaten]."</td><td>".$r[kecamatan]."</td><td>".$r[kode_pos]."</td><td>".$r[no_telp]."</td></tr>";
      }
    ?>
    </Table>
    </div>
    <?php	
    }
    ?>
    
    </div>
    </body>
    </html>
    <?php 
    if($aksi=='pesan'){
      ?>
          <div class="main">
        <div class="isimain">
    <span class="span">Pesanan</span> 
    <style>
    td,th{border:1px solid #ccc;padding:10px;}
    table{border-collapse:collapse;}
    b{background: red; font-size: 14px; color: #fff; padding: 10px;}
    p{background: #486; font-size: 14px; color: #fff; padding: 10px;}
    k{background: #4689DB; font-size: 14px; color: #fff; padding: 10px;}
    n{background: #467; font-size: 14px; color: #fff; padding: 10px;}
    td a{background: #2ecc71; padding: 5px; color: #fff; border-radius: 3px;}
    
    </style>
        <table>
        <tr>
        <th>Status</th><th>Nama</th><th>Jumlah barang</th><th>Jumlah bayar</th><th>tanggal beli</th><th>alamat</th><th>Konfirmasi</th><th>Dikirim</th><th>Sampai Kota</th><th>Diterima</th><th>Selesai</th><th>Hapus</th>
        </tr>
        <tr>
        <?php $transaksi=$db->selesai(); 
      foreach($transaksi as $r){
        if($r[konfir]=='N'){
          
          $konfir="<b>belum</b>";
          }
        elseif($r[konfir]=='Y'){
          $konfir="<p>dibayar</p>";
          }
          elseif($r[konfir]=='K'){
          $konfir="<p>dikirim</p>";
          }
          elseif($r[konfir]=='KK'){
          $konfir="<k>Sampai</k>";
          }
          elseif($r[konfir]=='T'){
          $konfir="<k>Diterima</k>";
          }
          elseif($r[konfir]=='S'){
          $konfir="<n>Selesai</n>";
          }
        echo "<tr><td>".$konfir."</td><td>".$r['nama']."</td><td>".$r['jumlah_barang']."</td><td>Rp.".$r['jumlah_bayar']."</td><td>".$r['tanggal_beli']."</td><td>".$r['alamat']."</td><td><a href='handler.php?aksi=konfir&id=".$r['id']."'>Konfirmasi</a></td><td><a href='handler.php?aksi=konfir_kirim&id=".$r['id']."'>Dikirim</a></td><td><a href='handler.php?aksi=konfir_kirim_kota&id=".$r['id']."'>Sampai</a></td><td><a href='handler.php?aksi=konfir_terima&id=".$r['id']."'>Diterima</a></td><td><a href='handler.php?aksi=konfir_selesai&id=".$r['id']."'>Selesai</a></td></tr>";
        ?>
        </div></div>
        <?php
        }
      
      ?>
        </table>
        <style type="text/css">
          input[type=submit]{margin:10px 0 10px 0;outline:0;background:#2ecc71;color:#fff;border:0;padding:10px;cursor:pointer}
        </style>
        <input type="submit" value="Cetak">   <input type="submit" value="Kirim Notifikasi">
      <?php
      }
    }
    ?>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
     
    </div>
    <strong>Copyright &copy; 2017-2018 <a href="http://localhost/project/zonafashion.com/admin/home.php">Zona Fashion</a>.</strong> All rights
    reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Create the tabs -->
    <ul class="nav nav-tabs nav-justified control-sidebar-tabs">
      <li><a href="#control-sidebar-home-tab" data-toggle="tab"><i class="fa fa-home"></i></a></li>
      <li><a href="#control-sidebar-settings-tab" data-toggle="tab"><i class="fa fa-gears"></i></a></li>
    </ul>
    <!-- Tab panes -->
    <div class="tab-content">
      <!-- Home tab content -->
      <div class="tab-pane" id="control-sidebar-home-tab">
        <h3 class="control-sidebar-heading">Recent Activity</h3>
        <ul class="control-sidebar-menu">
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa fa-birthday-cake bg-red"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Langdon's Birthday</h4>

                <p>Will be 23 on April 24th</p>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa fa-user bg-yellow"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Frodo Updated His Profile</h4>

                <p>New phone +1(800)555-1234</p>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa fa-envelope-o bg-light-blue"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Nora Joined Mailing List</h4>

                <p>nora@example.com</p>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <i class="menu-icon fa fa-file-code-o bg-green"></i>

              <div class="menu-info">
                <h4 class="control-sidebar-subheading">Cron Job 254 Executed</h4>

                <p>Execution time 5 seconds</p>
              </div>
            </a>
          </li>
        </ul>
        <!-- /.control-sidebar-menu -->

        <h3 class="control-sidebar-heading">Tasks Progress</h3>
        <ul class="control-sidebar-menu">
          <li>
            <a href="javascript:void(0)">
              <h4 class="control-sidebar-subheading">
                Custom Template Design
                <span class="label label-danger pull-right">70%</span>
              </h4>

              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-danger" style="width: 70%"></div>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <h4 class="control-sidebar-subheading">
                Update Resume
                <span class="label label-success pull-right">95%</span>
              </h4>

              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-success" style="width: 95%"></div>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <h4 class="control-sidebar-subheading">
                Laravel Integration
                <span class="label label-warning pull-right">50%</span>
              </h4>

              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-warning" style="width: 50%"></div>
              </div>
            </a>
          </li>
          <li>
            <a href="javascript:void(0)">
              <h4 class="control-sidebar-subheading">
                Back End Framework
                <span class="label label-primary pull-right">68%</span>
              </h4>

              <div class="progress progress-xxs">
                <div class="progress-bar progress-bar-primary" style="width: 68%"></div>
              </div>
            </a>
          </li>
        </ul>
        <!-- /.control-sidebar-menu -->

      </div>
      <!-- /.tab-pane -->
      <!-- Stats tab content -->
      <div class="tab-pane" id="control-sidebar-stats-tab">Stats Tab Content</div>
      <!-- /.tab-pane -->
      <!-- Settings tab content -->
      <div class="tab-pane" id="control-sidebar-settings-tab">
        <form method="post">
          <h3 class="control-sidebar-heading">General Settings</h3>

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Report panel usage
              <input type="checkbox" class="pull-right" checked>
            </label>

            <p>
              Some information about this general settings option
            </p>
          </div>
          <!-- /.form-group -->

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Allow mail redirect
              <input type="checkbox" class="pull-right" checked>
            </label>

            <p>
              Other sets of options are available
            </p>
          </div>
          <!-- /.form-group -->

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Expose author name in posts
              <input type="checkbox" class="pull-right" checked>
            </label>

            <p>
              Allow the user to show his name in blog posts
            </p>
          </div>
          <!-- /.form-group -->

          <h3 class="control-sidebar-heading">Chat Settings</h3>

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Show me as online
              <input type="checkbox" class="pull-right" checked>
            </label>
          </div>
          <!-- /.form-group -->

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Turn off notifications
              <input type="checkbox" class="pull-right">
            </label>
          </div>
          <!-- /.form-group -->

          <div class="form-group">
            <label class="control-sidebar-subheading">
              Delete chat history
              <a href="javascript:void(0)" class="text-red pull-right"><i class="fa fa-trash-o"></i></a>
            </label>
          </div>
          <!-- /.form-group -->
        </form>
      </div>
      <!-- /.tab-pane -->
    </div>
  </aside>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->

<!-- jQuery 2.2.3 -->
<script src="plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 3.3.6 -->
<script src="bootstrap/js/bootstrap.min.js"></script>
<!-- Material Design -->
<script src="dist/js/material.min.js"></script>
<script src="dist/js/ripples.min.js"></script>
<script>
    $.material.init();
</script>
<!-- Morris.js charts -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
<script src="plugins/morris/morris.min.js"></script>
<!-- Sparkline -->
<script src="plugins/sparkline/jquery.sparkline.min.js"></script>
<!-- jvectormap -->
<script src="plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<!-- jQuery Knob Chart -->
<script src="plugins/knob/jquery.knob.js"></script>
<!-- daterangepicker -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.11.2/moment.min.js"></script>
<script src="plugins/daterangepicker/daterangepicker.js"></script>
<!-- datepicker -->
<script src="plugins/datepicker/bootstrap-datepicker.js"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<!-- Slimscroll -->
<script src="plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/app.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
<!-- jQuery 2.2.3 -->
<script src="../../plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="../../bootstrap/js/bootstrap.min.js"></script>
<!-- Material Design -->
<script src="../../dist/js/material.min.js"></script>
<script src="../../dist/js/ripples.min.js"></script>
<script>
    $.material.init();
</script>
<!-- DataTables -->
<script src="../../plugins/datatables/jquery.dataTables.min.js"></script>
<script src="../../plugins/datatables/dataTables.bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="../../plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="../../plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/app.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>
<!-- page script -->
<script>
  $(function () {
    $("#example1").DataTable();
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false
    });
  });
</script>
</body>
</html>
