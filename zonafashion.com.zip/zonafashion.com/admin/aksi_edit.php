<?php
error_reporting(E_ALL ^ E_NOTICE);
include 'koneksi.php';


$id = $_POST['id'];

$nama = $_POST['nama'];
$Jenis_Kelamin = $_POST['Jenis_Kelamin'];
$kelas = $_POST['Kelas'];
$alamat = $_POST['alamat'];


$update = "UPDATE SISWA SET nama='$nama',Jenis_Kelamin='$Jenis_Kelamin',Kelas='$kelas',alamat='$alamat' where id = '$id'";
$hasil = mysql_query($update);




if ($hasil){
//header ('location:view.php');
echo " <center> Data Berhasil diupdate <br/>
<br> Untuk melihat daftar peserta klik <a href = 'index.php'> Disini </a></center>";
} else { echo "Data gagal diupdate";
}

?> 